package com.example.fastyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivityReserva extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_reserva);
    }
}